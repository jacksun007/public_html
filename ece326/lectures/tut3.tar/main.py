import numpy as np
import time

class TicTacToe:

    board = np.array([[" "," "," "],[" "," "," "],[" "," "," "]]) # stores the board of the game
    turn = 'X' # the current turn
    player = 'X' # player sign
    ai = 'O' # ai sign
    counter = 0

	# constructor
    def __init__(self, boardParam = None, turnParam = None, playerParam = None):
        if(isinstance(boardParam, np.ndarray)):
            self.board = boardParam
        if(turnParam != None):
            self.turn = turnParam
        if(playerParam != None):
            self.player = playerParam
            if(self.player == 'X'):
                self.ai = 'O'
            else:
                self.ai = 'X'

	# prints the current board
    def printBoard(self, board):
        print("|-|-|-|")
        for row in board:
            thisLine = "|"
            for entry in row:
                thisLine += str(entry)
                thisLine += "|"
            print(thisLine)
            print("|-|-|-|")

    # makes the next move according to the given coordinates and current turn
    def move(self, coords):
        coordX = coords[0]
        coordY = coords[1]
        if(self.board[coordX][coordY] == " "):
            self.board[coordX][coordY] = self.turn
            if (self.turn == self.player):
                self.turn = self.ai
            else: 
                self.turn = self.player
            return 1
        else:
            return 0

    def gameResult(self):
        return self.checkWinner(self.board)

    # checks if there is a winner or game is finished tie
    def checkWinner(self,board):
        # check winner in rows
        for row in board:
            starter = row[0]
            if(list(row).count(starter) == 3 and starter != " "):
                return starter
        # check winner in cols
        for col in board.T:
            starter = col[0]
            if(list(col).count(starter) == 3 and starter != " "):
                return starter
        # check winner in diag1
        mainDiag = [board[0,0],board[1,1],board[2,2]]
        starter = mainDiag[0]
        if(mainDiag.count(starter) == 3 and starter != " "):
            return starter
        # check winner in diag2
        otherDiag = [board[0,2],board[1,1],board[2,0]]
        starter = otherDiag[0]
        if(otherDiag.count(starter) == 3 and starter != " "):
            return starter
        # check for tie
        if(len(self.emptyCoords(board)) == 0):
            return "tie"
        # if none of the above: game continues
        return ""
		
    # returns available coordinates for next move
    def emptyCoords(self, board):
        coords = []
        for row in range(3):
            for col in range(3):
                if board[row][col] == " ":
                    coords.append([row,col])
        return coords

    # memorizing move
    def memorize(self, board, move, turn):
        if(turn == self.ai):
            board[board == 'X'] = 0
            board[board == 'O'] = 1
        else:
            board[board == 'X'] = 1
            board[board == 'O'] = 0
        boardStr = str(board.flatten())
        moveStr = str(move)
        file = open("memory.txt",'a')
        file.write(boardStr + ":" + moveStr + '\n')
        file.close()
        
    # searching memorized moves
    def searchMemory(self, board, turn):
        if(turn == self.ai):
            board[board == 'X'] = 0
            board[board == 'O'] = 1
        else:
            board[board == 'X'] = 1
            board[board == 'O'] = 0
        file = open("memory.txt")
        for line in file:
            flattenBoard, move = line.split(":")
            if(flattenBoard == str(board.flatten())):
                move = move.strip('\n[]')
                moveX,moveY = move.split(',')
                moveY = moveY.strip()
                file.close()
                return [turn,moveX,moveY]
        file.close()
        return 0

    # choosing next move for AI
    def pickNextMove(self, board, turn):
        # Reading from memory
        memSearch = self.searchMemory(board.copy(),turn) 
        if(memSearch):
            return memSearch
        if(self.checkWinner(board) != ""):
            return [self.checkWinner(board),-1,-1]
        bestX = -1
        bestY = -1

        #win if possible
        for availableCoord in self.emptyCoords(board):
            tmpBoard = np.array(board) # store temp board
            # place temp move
            moveX = availableCoord[0]
            moveY = availableCoord[1]
            tmpBoard[moveX][moveY] = turn
            
            # check winner with proposed move
            if(self.checkWinner(tmpBoard) == turn):
                bestX = moveX
                bestY = moveY
                # Memoisation
                self.memorize(board.copy(), [bestX,bestY],turn)
                return [turn,bestX,bestY]

        #prevent oponent win
        for availableCoord in self.emptyCoords(board):
            tmpBoard = np.array(board) # store temp board
            # place temp move
            moveX = availableCoord[0]
            moveY = availableCoord[1]
            op = ''
            if(turn == self.ai):
                op = self.player
            else:
                op = self.ai
            tmpBoard[moveX][moveY] = op
            
            # check winner with proposed move
            if(self.checkWinner(tmpBoard) == op):
                bestX = moveX
                bestY = moveY
                # Memoisation
                self.memorize(board.copy(), [bestX,bestY],turn)
                return [turn,bestX,bestY]

        # Depth-First Seach
        for availableCoord in self.emptyCoords(board):
            tmpBoard = np.array(board)
            moveX = availableCoord[0]
            moveY = availableCoord[1]
            tmpBoard[moveX][moveY] = turn
            nextTurn = ''
            if(turn == self.player):
                nextTurn = self.ai
            else:
                nextTurn = self.player
            result = self.pickNextMove(tmpBoard,nextTurn)[0] # recursive
            
            if(result == turn): # If result is as we want
                bestX = moveX
                bestY = moveY
                self.memorize(board.copy(), [bestX,bestY], turn)
            elif(result == self.player): # If result is not good
                return [-1,moveX,moveY]
            elif(self.checkWinner(tmpBoard) == 'tie'): # If result is a tie
                return [0,moveX,moveY]
        return [result,bestX,bestY]
          

    def aiMove(self):
        result = self.pickNextMove(self.board.copy(), self.ai)
        return [int(i) for i in result[1:]]

    # gets player move from input + input checks
    def getPlayerMove(self):
        wrongInput = True
        while(wrongInput):
            wrongInput = False
            moveCoords = input("Enter your move(coordinates separated by comma):")
            moveCoords = moveCoords.split(',')
            if(len(moveCoords) != 2):
                wrongInput = True
            if(all(str.isdigit(x) for x in moveCoords)):
                moveCoords = [int(i) for i in moveCoords]
            else:
                wrongInput = True
            if(not wrongInput and (moveCoords[0] > 2 or moveCoords[0] < 0 or moveCoords[1] > 2 or moveCoords[1] < 0 or len(moveCoords) != 2)):
                wrongInput = True
            if(wrongInput):
                print("Wrong input! Please try again.")
                continue
            
            
        return moveCoords

    # runs the game
    def run(self):
        self.printBoard(self.board.copy())
        while(self.gameResult() == ''): # while the game is on (no winners and no tie)
            # Player turn
            if(self.turn == self.player):
                print("Your turn(" + self.player + "):")
                moveCoords = self.getPlayerMove()
                if(not self.move(moveCoords) ):
                    print("Wrong move!")
                    continue
                self.printBoard(self.board.copy())
            # AI turn
            else:
                print("Computer turn(" + self.ai + "):")
                t1 = time.time()
                moveCoords = self.aiMove()
                t2 = time.time()
                print("Loading time: " + str(t2 - t1))
                self.move(moveCoords)
                self.printBoard(self.board.copy())
        gameRes = self.gameResult()
        print('***********************************')
        self.printBoard(self.board.copy())
        if(gameRes == self.player):
            print('Congrats! Player Won!')
        elif(gameRes == self.ai):
            print('AI won.')
        elif(gameRes == 'tie'):
            print('Tie! No winner.')

def main():
    #ticTacToe = TicTacToe(np.array([["X"," "," "],[" ","O"," "],[" "," ","X"]]),'O','X')
    ticTacToe = TicTacToe(None,None,'X')
    ticTacToe.run()
    

if __name__=='__main__':
    main()