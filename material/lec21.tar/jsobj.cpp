/*
 * jsobj.cpp
 *
 * variadic template with inheritance and member function template
 * (slide 7)
 */

#include <iostream>
#include <sstream>
#include <string>

namespace JsField {
    template<typename T>
    std::string print(const T val) {
        std::ostringstream out;
        out << val;
        return out.str();
    }
    
    template<>
    std::string print(const char * val) {
        std::ostringstream out;
        out << "\"" << val << "\"";
        return out.str();
    }
}

template<typename ... Names>
class JsObject {
protected:
    std::ostream & os;

    void encode_recursive() {
        os << "}" << std::endl;
    }

    JsObject(std::ostream & os) : os(os) {}
};

template<typename T, typename ... Names>
class JsObject<T, Names...> : public JsObject<Names...> {
    std::string name;
    
protected:
    template<typename V, typename ... Args>
    void encode_recursive(const V & val, Args ... args) {
        this->os << name << " : " << JsField::print(val) << ", ";
        this->JsObject<Names...>::encode_recursive(args...);
    } 
       
public:
    JsObject(std::ostream & os, const T & name, Names ... names) 
        : JsObject<Names...>(os, names...), name(name) {}

    template<typename ... Args>
    void encode(Args ... args) {
        this->os << "{ ";
        this->encode_recursive(args...);
    }
};

template<typename ... Args>
JsObject<Args...> new_js_object(std::ostream & os, Args ... args) {
    return JsObject<Args...>(os, args...);
}

int main() {
    auto jsobj = new_js_object(std::cout, "name", "age", "height");
    jsobj.encode("Bob", 23, 6.8);
    jsobj.encode("Jane", 21, 5.9);
    return 0;
}

