/*
 * printc.cpp
 *
 * Using variadic template to print any container (slide 18)
 */

#include <iostream>
#include <vector>
#include <list>
#include <unordered_map>

using namespace std;

template <template <typename, typename...> class CT,
          typename ValueType, typename... Args>
void print_container(const CT<ValueType, Args...>& c) {
  for (const auto & v : c) {
    std::cout << v << ' ';
  }
  std::cout << '\n';
}

// this is necessary for printing std::pair, which
// is returned during the foreach loop
template <typename T, typename U>
std::ostream& operator<<(std::ostream& out, 
                         const std::pair<T, U>& p) {
  out << "(" << p.first << ", " << p.second << ")";
  return out;
}

int main()
{
	std::vector<double> vd{3.14, 8.1, 3.2, 1.0};
	print_container(vd);

	std::list<int> li{1, 2, 3, 5};
	print_container(li);
	
	std::unordered_map<string, int> msi{
	    {"foo", 42}, {"bar", 81}, {"baz", 4}};
	print_container(msi);

	return 0;
}
