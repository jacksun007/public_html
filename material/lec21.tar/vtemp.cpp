/*
 * vtemp.cpp
 *
 * Using normal template to print any container (doesn't work)
 * (slide 17)
 */

#include <iostream>
#include <vector>
#include <list>
#include <unordered_map>

using namespace std;

template <template <typename, typename> class CT,
          typename ValueType, typename Alloc>
void print_container(const CT<ValueType, Alloc>& c) {
  for (const auto& v : c) {
    std::cout << v << ' ';
  }
  std::cout << '\n';
}

template <typename T, typename U>
std::ostream& operator<<(std::ostream& out, 
                         const std::pair<T, U>& p) {
  out << "(" << p.first << ", " << p.second << ")";
  return out;
}

int main()
{
	std::vector<double> vd{3.14, 8.1, 3.2, 1.0};
	print_container(vd);

	std::list<int> li{1, 2, 3, 5};
	print_container(li);
	
	// this doesn't work
	std::unordered_map<string, int> msi{
	    {"foo", 42}, {"bar", 81}, {"baz", 4}};
	print_container(msi);

	return 0;
}

