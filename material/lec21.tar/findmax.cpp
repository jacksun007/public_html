/*
 * findmax.cpp
 *
 * variadic function to calculate max in a list (slide 7)
 */

#include <cstdlib>
#include <iostream>
#include <cstdarg>
#include <cstdio> 

int find_max(int n, ...) { 
    int i, val, largest; 
    va_list vl;   
    va_start(vl, n); 
    largest = va_arg(vl, int);  
    for (i = 1; i < n; i++) {   
        val = va_arg(vl, int); 
        largest = (largest > val) ? largest : val; 
    } 
    va_end(vl); 
    return largest; 
}

int main(int argc, const char * argv[])
{ 
    int value = ::atoi(argv[argc-1]);
    // type unsafe! find_max expects integers
    int x = find_max(3, -1000., value, 1000.);
    std::cout << "largest = " << x << std::endl;
    return 0;
}

