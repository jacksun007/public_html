/*
 * vfunc.cpp
 *
 * variadic function using vfprintf (slide 4)
 */

#include <cstdarg>
#include <cstdio> 

// normal printf sends output to stdout
// eprintf sends output to stderr (error console output)
int eprintf(const char * fmt, ...) { 
    va_list args;     // stores variable argument list
    va_start(args, fmt);

    fprintf(stderr, "ERROR: "); 
    // like fprintf, but takes va_list instead of ...
    int ret = vfprintf(stderr, fmt, args); 
    va_end(args); 
    return ret; 
}

int not_ok(...) {
    return 0;
}

int main() {
    int ret = not_ok(1, 2, "hello", 3.4);
    eprintf("not_ok returned %d\n", ret);
    return 0;
}
