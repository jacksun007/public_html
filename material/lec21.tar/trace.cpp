/*
 * trace.cpp
 *
 * variadic template function argument forwarding (slide 15)
 */

#include <iostream>

using namespace std;

template<typename ... Args>
void print_arguments() {
    cout << endl;
}

template<typename T, typename ... Args>
void print_arguments(T val, Args ... args) {
    cout << val << ", ";
    print_arguments(args...);
}

template<typename RT, typename ... Args>
RT trace(RT (*func)(Args...), Args ... args) {
    cout << "Arguments: ";
    print_arguments(args ...);
    auto ret = func(args ...);
    cout << "Return value: " << ret << endl;
    return ret;
}

int foo(int a, const char * b, double c) {
    // note that atoi returns 0 if conversion fails
    return a + ::atoi(b) + (int)c;
}

int main()
{
    cout << "Tracing function call for foo\n";
	trace(foo, 2, "hello", 4.5);
	return 0;
}

