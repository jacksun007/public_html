/*
 * isin.cpp
 *
 * Example of variadic template function (slide 13)
 */

#include <iostream>

template<typename T> 
bool is_in(T & a, T b) {
    std::cout << "base criteria reached\n";
    return a == b; 
} 

template<typename T, typename... Args> 
bool is_in(T & a, T b, Args... args) {
    std::cout << "args contains " << sizeof...(args)
              << " elements\n"; 
    return a == b || is_in(a, args...); 
} 

int main(int argc, const char * argv[])
{ 
    char c = 'X';
    if (is_in(c, 'A', 'T', 'J', 'Q', 'K')) { 
        std::cout << c << " is found\n";    
    }
    else {
        std::cout << c << " is not found\n";
    }
    
    return 0;
} 

