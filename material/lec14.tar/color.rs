/*
 * color.rs 
 *
 * Show destructuring of enum variants (slide 18)
 * 
 */
 
use std::env;

pub enum Color {
    RGB(u32, u32, u32), 
    HSV(u32, u32, u32), 
    CMYK(u32, u32, u32, u32), 
} 

fn main() 
{
    let args : Vec<String> = env::args().collect();
    let color = Color::RGB( 
                 args[1].parse().unwrap(),
                 args[2].parse().unwrap(),
                 args[3].parse().unwrap(), 
    );

    match color {
        // this is how you write a multiline string in Rust
        Color::RGB(r, g, b) => println!("Red: {}, green: \
            {}, and blue: {}!", r, g, b), 
        _ => println!("We don't care about other models!"),
    }
}

