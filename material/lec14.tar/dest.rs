/*
 * dest.rs 
 *
 * Show how destructuring in match statement works (slide 15)
 * 
 */
 
use std::env;

fn main() 
{
    let args : Vec<String> = env::args().collect();
    let pair = ( args[1].parse::<isize>().unwrap(),
                 args[2].parse::<isize>().unwrap() );

    match pair { 
        (0, y) => println!("First is 0 and y is {}", y),
        (x, 0) => println!("x is {} and last is 0", x), 
             _ => println!("It doesn't matter"), 
    }
}

