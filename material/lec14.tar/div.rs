/*
 * div.rs 
 *
 * Show how Option<T> works (slide 19)
 * 
 */
 
use std::env;

fn int_div(a: i32, b: i32) -> Option<i32> {
    if a % b == 0 {
        Some(a/b)
    }
    else {
        None
    }
}

fn main() 
{
    let args : Vec<String> = env::args().collect();
    let (a, b) = (args[1].parse().unwrap(),
                  args[2].parse().unwrap(), );
    
    match int_div(a, b) {
        Some(x) => println!("{} / {} = {}", a, b, x),
        None => println!("{} is not divisible by {}", a, b),
    }
}

