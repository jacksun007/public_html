/*
 * file.rs 
 *
 * Show how to work with Result<T, E> (slide 21)
 * 
 */
 
use std::env;
use std::fs::File;  // needed for file object
use std::io::Read;  // needed for read_to_string

fn main() 
{
    let args : Vec<String> = env::args().collect();
    let filename = &args[1];
    
    let mut f = match File::open(&filename) {
        Ok(file) => file, 
	    Err(error) => { 
		    panic!("There was a problem opening {}: \
			     {:?}", filename, error) 
	    }, 
    };
    
    let mut s = String::new();
    f.read_to_string(& mut s).unwrap();
    println!("{}", s);
}

