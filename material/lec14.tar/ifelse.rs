/*
 * ifelse.rs 
 *
 * Show how if else can be used as expression (slide 3)
 * 
 */

use std::env;

fn main() 
{
    let args : Vec<String> = env::args().collect();
    let n = args[1].parse::<isize>().unwrap();
    
    if n < 0 { 
	    print!("{} is negative", n); 
    } else if n > 0 { 
	    print!("{} is positive", n); 
    } else { 
	    print!("{} is zero", n); 
    }
    
    let big_n = if n < 10 && n > -10 { 
	    println!(", a small number, increase ten-fold."); 	
	    10 * n // no semicolon here 
    } else { 
	    println!(", a big number, halve the number."); 
	    n / 2 
    } // semicolon here (let is a statement)

    println!("{} -> {}", n, big_n); 
}
