/*
 * mloop.rs 
 *
 * Shows a move for loop (slide 11)
 * 
 */

fn main() 
{
    let v = vec![1, 2, 3]; 
    let mut n = 0; 
    
    for i in v { 
        n += i; 
    }
   
    // uncomment this to see compiler error
    println!("v is {:?}", v);
    
    println!("n is {}", n);
}

