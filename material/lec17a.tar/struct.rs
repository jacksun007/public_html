/*
 * struct.rs 
 *
 * Shows how lifetime works with structures (slide 10)
 * 
 */

#[derive(Debug)]
pub struct ImportantExcerpt<'a> { 
    part: &'a str, 
} 

impl<'a> ImportantExcerpt<'a> { 
    pub fn level(&self) -> i32 { 3 } 
} 

fn main() { 
    let novel = String::from("Hello World. A long time ago..."); 
    let first = novel.split('.').next().expect("Split failed");
    let i = ImportantExcerpt { part: first }; 
    println!("{:?}", i);
}

