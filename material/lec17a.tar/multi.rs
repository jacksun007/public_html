/*
 * multi.rs 
 *
 * Shows how multiple lifetimes works (slide 12)
 * 
 */

// this doesn't work
fn choose_first<'a, 'b>(x: &'a i32, y: &'b i32) -> &'a i32 
{
    println!("{} is the second", y);
    x
} 

fn main() 
{ 
    let first = 2;
    let ret;
    
    { 
        let second = 3; 
        ret = choose_first(&first, &second);  
    }
    
    println!("{} is the first", ret); 
}

