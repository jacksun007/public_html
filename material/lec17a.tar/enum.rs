/*
 * enum.rs 
 *
 * Shows how lifetime works with enums and static lifetime
 * (slide 11)
 * 
 */


#[derive(Debug)]
enum Either<'a> { 
	Num(i32), 
	Ref(&'a i32), 
	StaticRef(&'static str), 
}

fn main() {
    let x   = 18; 
    let rx  = Either::Ref(&x); 
    let num = Either::Num(15); 
    let sr  = Either::StaticRef("bonjour");
    
    // this will not compile
    let s = String::from("hello");
    let sr2 = Either::StaticRef(s.as_str());

    println!("{:?}, {:?}, {:?}", rx, num, sr);
}

