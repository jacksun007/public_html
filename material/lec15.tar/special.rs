/*
 * special.rs 
 *
 * Show specialization for generic type (slide 12)
 * 
 */

#[derive(Debug)] 
struct Point<T> { x: T, y: T, } 

impl Point<f32> { 
	fn distance_from_origin(&self) -> f32 
	{ 
		(self.x.powi(2) + self.y.powi(2)).sqrt() 
	} 
}

fn main() {
    let pf = Point { x: 2.5, y: 3.5 }; 
    let dist = pf.distance_from_origin(); 
    println!("distance from origin: {}", dist);

    let pi : Point<i32> = Point { x: 2, y: 4 };
    
    // this will not compile 
    // let dist = pi.distance_from_origin(); 
    
    println!("{:?} to origin: {}", pi, dist);
}
