/*
 * rect.rs 
 *
 * Show method definition for Rectangle (slide 5)
 * 
 */

mod point;
use point::Point;

#[derive(Debug)]
struct Rectangle { p1: Point, p2: Point, }

impl Rectangle { 
	fn perimeter(&self) -> f64 { 
		let Point { x: x1, y: y1 } = self.p1; 
		let Point { x: x2, y: y2 } = self.p2; 
		2.0 * ((x1 - x2).abs() + (y1 - y2).abs()) 
	} 
	
	fn translate(&mut self, x: f64, y: f64) { 
		self.p1.translate(x, y); 
		self.p2.translate(x, y); 
	} 
} 

fn main() {
    let mut square = Rectangle { 
	    p1: Point::origin(), p2: Point::new(1.0, 1.0), 
    }; 

    println!("my perimeter is: {}", square.perimeter()); 
    
    square.translate(2.0, 3.0); 		 // OK – square mutable 
    println!("square: {:?}", square);
}

