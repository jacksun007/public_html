/*
 * struct.rs 
 *
 * Show how to declare new structs and instantiate them (slide 2)
 * 
 */

#[derive(Debug)]
struct Point { x: f32, y: f32, } 

#[derive(Debug)]
struct Rectangle { p1: Point, p2: Point, }

fn main() {
    let p: Point = Point { x: 0.3, y: 0.4 }; 
    let rect = Rectangle { 
	    p1: Point { x: 0.2, y: 0.5 }, 
	    // structures can be owners, so p is moved into rect
	    p2: p,
    };
    
    println!("{:?}", rect);  
    
    // you will get an error if you uncomment this
    println!("{:?}", p);  
}

