/*
 * largest.rs 
 *
 * Show how trait bound works (slide 14)
 * 
 */

fn largest<T: PartialOrd + Copy>(list: &[T]) -> T 
{ 
	let mut largest = list[0]; 
	for &item in list { 
		if item > largest { 
			largest = item; 
		} 
	} 
	largest 
}

fn main() {
    let a = [4, 2, 0, 6, 9];
    println!("largest = {}", largest(&a));
}

