/*
 * dest.rs 
 *
 * Show how to destructure a structure (slide 3)
 * 
 */

struct Point { x: f32, y: f32, z: f32 } 

fn main() {
    let p: Point = Point { x: 0.3, y: 0.4, z: 0.5 }; 

    // destructure a structure 
    let Point { x: my_x, y: my_y, z: _ } = p; 
    
    // destructure just one of the fields
    let Point { z: my_z, .. } = p; 

    println!("my 2D point at ({}, {})", my_x, my_y); 
    println!("z = {}", my_z);
}

