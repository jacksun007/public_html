/*
 * constarr.cpp
 *
 * Example of constexpr array (slide 15)
 */

#include <iostream>

constexpr int sum_recursive(const int a[], unsigned n) { 
    return (n == 0) ? 0 : a[0] + sum_recursive(a+1, n-1); 
} 

template<int N>
constexpr int sum(const int (&a)[N]) { 
    return sum_recursive(a, N);
} 

template<int N>
constexpr char midchar(const char (&s)[N]) {
    return s[(N-1)/2];  // N includes the null character
}

int main() {
    constexpr int a[] = {1, 2, 3, 4};
    std::cout << midchar("goodbye") << std::endl;
    constexpr auto i = sum(a);
    std::cout << i << std::endl;
    
    // uncomment this to see compile-time 
    // array out of bound error
    constexpr auto x = sum_recursive(a, 6);
    
    return 0;
}
