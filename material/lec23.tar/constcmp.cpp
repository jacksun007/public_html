/*
 * constcmp.cpp
 *
 * Example of constexpr string compare function (slide 12)
 */

#include <iostream>

/* lexicographical comparison of two constant strings */ 
/* returns positive if a > b, negative if a < b, 0 if equal */
constexpr int constcmp(const char * a, const char * b) { 
    return (a[0] == '\0') ? (a[0] - b[0]) : 
        ( 
            (a[0] == b[0]) ? 
                constcmp(a+1, b+1) : 
                a[0] - b[0] 
        ); 
} 

template<int C>
void print_result(const char * a, const char * b) {
    if (C < 0) {
        std::cout << a << " < " << b << std::endl;
    }
    else if (C > 0) {
        std::cout << a << " > " << b << std::endl;
    }
    else {
        std::cout << a << " == " << b << std::endl;
    }
}

int main() {
    print_result<constcmp("he", "hello")>("he", "hello");
    print_result<constcmp("hello", "hell")>("hello", "hell");
    print_result<constcmp("hey", "hey")>("hey", "hey");
    
    return 0;   
}


