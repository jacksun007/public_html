/*
 * constrect.cpp
 *
 * Example of constexpr Rectangle class (slide 16)
 */

#include <iostream>

using namespace std;

class Rectangle { 
    int _h, _w; 
public: 
    // a constexpr constructor 
    constexpr Rectangle (int h, int w) : _h(h), _w(w) {} 
    constexpr int area () { return _h * _w; } 
}; 

int main(int argc, const char * argv[]) {
    constexpr Rectangle rekt(10, 20); // compile-time       
    constexpr auto area = rekt.area();
    cout << "rekt area = " << area << endl; 

    Rectangle rect(5, argc);          // runtime Rectangle 
    cout << "rect area = " << rect.area() << endl;     

    return 0;
}

