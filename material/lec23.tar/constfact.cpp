/*
 * constfact.cpp
 *
 * Example of constexpr factorial function (slide 12)
 */

#include <iostream>

constexpr int factorial(int n) { 
    return n <= 1 ? 1 : (n * factorial(n - 1)); 
} 

int main() {
    // this value is computed at compile-time!
    constexpr auto f5 = factorial(5);
    
    std::cout << "factorial(5) = " << f5 << std::endl;
    
    return 0;
}

