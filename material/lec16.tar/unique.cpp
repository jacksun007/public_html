#include <memory> 
#include <iostream>

using namespace std;

class Point {
    int x, y;
public:
    Point(int x, int y) : x(x), y(y) {}
    
    friend ostream & operator<<(ostream &, const Point &);      
};

ostream & operator<<(ostream &os, const Point &p) {
    return os << "(" << p.x << ", " << p.y << ")";
}

int main() { 
	unique_ptr<Point> point(new Point(1, 2));
	
	// point behaves like a normal pointer
	cout << "point is " << *point << endl;
	
	return 0;
	// Destructor of point deletes memory automatically, 
	// no need to explicitly write “delete point;”
}

