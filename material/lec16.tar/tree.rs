/*
 * tree.rs 
 *
 * Shows how to use Box to implement BST (slide 7)
 * 
 */

enum Tree {
    Leaf,
    Node(i64, Box<Tree>, Box<Tree>)
}

use Tree::{Leaf, Node};

fn add_values(tree: Tree) -> i64 {
    match tree {
        Tree::Node(v, a, b) => {
	      v + add_values(*a) + 
            add_values(*b)
      },
	Tree::Leaf => 0
    }
}

fn main() {
    let n4 = Box::new(Node(4, Box::new(Leaf), Box::new(Leaf)));
    let n3 = Box::new(Node(3, Box::new(Leaf), n4));
    let n0 = Box::new(Node(0, Box::new(Leaf), Box::new(Leaf)));
    let root = Node(2, n3, n0);
    let v = add_values(root);
    println!("sum = {}", v);
}

