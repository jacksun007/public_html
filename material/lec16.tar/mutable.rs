/*
 * mutable.rs 
 *
 * Shows how mutability works on a move (slide 9)
 * 
 */

fn main() {
    let v = vec![1, 2, 3];

    println!("v = {:?}", v);
    let mut w = v;
    // name binding v is removed
    
    w.push(4);
    println!("w = {:?}", w);
}
