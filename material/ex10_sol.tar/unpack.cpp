#include <iostream>
#include <string>

template<typename ... Args> struct ArgPack;

template<typename T, typename ... Args>
struct ArgPack<T, Args...> : public ArgPack<Args...> {
    T value;
    ArgPack(const T & v, Args ... args) : 
        ArgPack<Args...>(args...), value(v) {}
};

template<typename ... Args>
ArgPack<Args...> pack_arguments(Args ... args) {
    return ArgPack<Args...>(args...);   
}

template<> struct ArgPack<> {};

template<typename ... Params>
class Unpacker {
    // function to call after unpacking is done
    void (*func)(Params...);
public:
    Unpacker(void (*func)(Params...)) : func(func) {}

    // progresive approach to base criteria
    template<template<typename...> class AP, 
             typename T,            // type of value stored at current class
             typename ... Rest,     // template arguments to parent class
             typename ... Args>     // actual arguments to function
    void unpack_and_call_recursive(AP<T, Rest...> argpack, Args ... args) 
    {
        unpack_and_call_recursive(
            (AP<Rest...> &)argpack, // cast argpack to parent class
            args ...,               // pack expansion
            argpack.value           // extract value *backwards* in call order
        );
    }
    
    // base criteria, all arguments from argpack unpacked
    template<typename ... Args>
    void unpack_and_call_recursive(ArgPack<> argpack, Args ... args) 
    {
        (void)argpack;  // this is empty now
        func(args...);  // args is filled with arguments
    }
        
    template<template<typename...> class AP>
    void unpack_and_call(AP<Params...> argpack) 
    {
        unpack_and_call_recursive(argpack);
    }
};

template<typename ... Args>
Unpacker<Args...> new_unpacker(void (*func)(Args ...)) {
    return Unpacker<Args...>(func);
}

void foo(std::string s, int i, double d, bool b) {
    std::cout << "s = " << s << std::endl;
    std::cout << "i = " << i << std::endl;
    std::cout << "d = " << d << std::endl;
    std::cout << "b = " << b << std::endl;
}

int main() {
    auto argpack = pack_arguments(std::string("hello"), 5, 3.21, false); 
    auto unpacker = new_unpacker(foo);
    unpacker.unpack_and_call(argpack);
    return 0;
}

