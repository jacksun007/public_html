/*
 * default.cpp
 *
 * Example of template class (slide 16)
 */

#include <iostream>
#include <cassert>

template<class T=int, int C=16> 
class Stack { 
    int end;
    T array[C]; // static array size
    
public: 
    Stack() : end(-1) {} 
  
    bool push(const T &); 
    bool pop();           
    T * top(); 

    int empty() const { return end == -1; } 
    int full() const { return end == C - 1; } 
};

template<class T, int C>
bool Stack<T, C>::push(const T & item) {
    if (full()) return false;
    array[++end] = item;
    return true;
}

template<class T, int C>
bool Stack<T, C>::pop() {
    if(empty()) return false;
    --end;
    return true;
}

template<class T, int C>
T * Stack<T, C>::top() {
    if (empty()) return nullptr;
    return &array[end];
}

using namespace std;

int main() {
    auto is = Stack<>();    // auto becomes Stack<>
    int * ip, i = 3;
    
    cout << "Pushing elements onto stack" << endl;
    while (is.push(i)) {
        cout << i << ' '; i += 2;
    }
    
    cout << endl << "stack full" << endl
         << endl << "Popping elements from stack" << endl ;
    
    while ((ip = is.top())) {
        cout << *ip << ' '; 
        is.pop();
    }
    cout << endl << "stack empty" << endl;
    
    return 0;
}

