/*
 * stack.cpp
 *
 * Example of template class (slide 11-13, 15)
 */

#include <iostream>
#include <cassert>

template<class T>	// same as typename T
class Stack {
    int count;  // capacity of stack
    int end;    // points to top of stack  
    T * array;

public:
    Stack(unsigned cnt=8); 
    ~Stack() { delete [] array; }
    
    bool push(const T &); // push element to top of stack
    bool pop(); 	      // remove current top of stack
    
    T * top();	          // return current top of stack by pointer
    T & top2();           // return current top of stack by reference
    
    int empty() const { return end == -1; } 
    int full() const { return end == count - 1; }  
};

template<class T>
Stack<T>::Stack(unsigned cnt) : count((int)cnt), end(-1), 
    array(new T[cnt]) {}

template<class T>
bool Stack<T>::push(const T & item) {
    if (full()) return false;
    array[++end] = item;
    return true;
}

template<class T>
bool Stack<T>::pop() {
    if(empty()) return false;
    --end;
    return true;
}

// general rule of thumb:
// return a pointer if you want to indicate error with nullptr
template<class T>
T * Stack<T>::top() {
    if (empty()) return nullptr;
    return &array[end];
}

// return by reference (T &) if no error is possible, OR
// if you plan to crash the program upon error
template<class T>
T & Stack<T>::top2() {
    /* this will crash the program if empty() is true */
    assert(!empty());
    return array[end];
}

// these two lines are equivalent
// using DoubleStack = Stack<double>;
typedef Stack<double> DoubleStack;

// allows you to drop std:: in front of cout/endl
using namespace std;

int main() {
    DoubleStack ds = DoubleStack();
    double * dp, d = 1.1;
    
    cout << "Pushing elements onto stack" << endl;
    while (ds.push(d)) {
        cout << d << ' '; d += 0.7;
    }
    
    cout << endl << "stack full" << endl
         << endl << "Popping elements from stack" << endl ;
    
    while ((dp = ds.top())) {
        cout << *dp << ' '; 
        ds.pop();
    }
    cout << endl << "stack empty" << endl;
    
    return 0;
}

