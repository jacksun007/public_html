/*
 * factorial.cpp
 *
 * Example of recursive template (slide 22)
 */

#include <iostream>

template<int F>
struct Factorial {
    enum { value = F * Factorial<F - 1>::value };
};

template<>
struct Factorial<1> {
    enum { value = 1 };
};

using namespace std;

int main() {
    // this value is calculated at compile-time
    cout << Factorial<5>::value << endl;
    
    return 0;
}

