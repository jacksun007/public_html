#pragma once

/* template declaration only */
template<typename T> T min(T a, T b);

template<typename T> 
T min(T a, T b) { 
    return a < b ? a : b; 
} 

