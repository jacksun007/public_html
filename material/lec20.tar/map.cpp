/*
 * map.cpp
 *
 * Example of partial template specialization (slide 19-20)
 * and partial template alias (slide 21)
 */

#include <cassert>
#include <iostream>
#include <cstring>
#include <string>

template<class K, class V, int S> 
class Map {
    int len;
    struct Pair { K key; V value; } array[S]; 
public: 
    Map() : len(0) {}

    bool insert(const K & k, const V & v) {
        if (len >= S)            // template too big
            return false;
            
        if (find(k) != nullptr)  // value already exists
            return false;    
            
        array[len].key = k;
        array[len].value = v;
        len++;
        return true;
    } 
    
    V * find(const K & k) { 
        int i; 
        for (i = 0; i < S; i++) {       
            if (array[i].key == k) 
                return &array[i].value; 
        }
        return nullptr; 
    } 
}; 

template<class V, int S> 
class Map<int, V, S>            // e.g. key is an int
{ 
    V values[S]; 
    bool valid[S];
public: 
    /* set all elements of valid array to false */
    Map() { ::memset(valid, 0, sizeof(valid)); }

    bool insert(int k, const V & v) {
        if (k < 0 || k >= S) // k must be between 0 and S-1
            return false;
        
        if (valid[k])        // k already mapped
            return false;   
        
        values[k] = v;
        valid[k] = true;
        return true;
    } 
    
    V * find(int k) {
        if (k < 0 || k >= S) 
            return nullptr;
        
        if (!valid[k])
            return nullptr;
        
        return &values[k]; 
    } 
}; 


using namespace std;

void map_test() {
    /* maps from float to string literal, capacity = 3 */
    auto fmap = Map<float, const char *, 3>();

    fmap.insert(3.14, "pi");
    fmap.insert(2.72, "e");
    fmap.insert(1.62, "golden ratio");
    
    // this should fail because map is full
    auto ret = fmap.insert(0., "zero");
    assert(ret == false);
    
    // this should fail because 3.14 exists
    ret = fmap.insert(3.14, "pie");
    assert(ret == false);
    
    cout << 1.62 << " is the " << *fmap.find(1.62) << endl;
}

void intmap_test() {
    auto imap = Map<int, float, 8>();

    imap.insert(1, 12.5);
    imap.insert(2, 15.3);
    
    // this should fail because 10 is out of bound
    auto ret = imap.insert(10, 17.5);
    assert(ret == false);
    
    // this should fail because 1 already mapped
    ret = imap.insert(1, 17.5);
    assert(ret == false);
    
    cout << 2 << " maps to " << *imap.find(2) << endl;
}

template<class K, int S> 
using StringMap = Map<K, std::string, S>; 

void stringmap_test() {
    /* this should use the regular Map because long != int */
    auto smap = StringMap<long, 4>();

    smap.insert(15, "hello");
    smap.insert(42, "world");
    
    // this should fail because 15 already mapped
    auto ret = smap.insert(15, "goodbye");
    assert(ret == false);
    
    cout << 42 << " maps to " << *smap.find(42) << endl;
}

int main() {
    //map_test();
    //intmap_test();
    stringmap_test();
    return 0;
}


