/*
 * vector.cpp
 *
 * Example of multiple type parameters (slide 10)
 */

#include <vector>
#include <iostream>

int main() {
    // this does not work
    //std::vector v = {1, 2, 3};
    
    std::vector<int> v = {1, 2, 3};
    
    for (auto it = v.begin(); it != v.end(); it++) {
        std::cout << *it << std::endl;
    }
    
    return 0;
}

