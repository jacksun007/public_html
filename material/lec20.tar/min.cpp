/*
 * min.cpp
 *
 * Example of illegal template argument substitution (slide 5)
 */

#include <iostream>

template<typename T> // T is a type 
T min(T a, T b) { 
    return a < b ? a : b; 
} 

template<typename T>
T foo(T bar) {
    return bar.what_is_this();   
}

class NotComparable {
    int x;
public:
    NotComparable(int x) : x(x) {}
};

int main() {
    std::cout << min<int>(4, 9) << std::endl;  
    
    // these will not work
    // std::cout << foo(5);
    std::cout << min(NotComparable(3), NotComparable(4));
     
    return 0;
}

