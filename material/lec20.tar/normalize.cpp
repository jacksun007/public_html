/*
 * normalize.cpp
 *
 * Example of non-type template parameter (slide 7)
 */
 
#include <iostream> 
 
template<typename T, int X>
void normalize(T array[], int size) {
    for (int i = 0; i < size; i++) {
        array[i] /= (T)X;
    }
}

int main() {
    double a[] = {5., 9., 12.};
    int b = 3;
    
    normalize<double, 5>(a, 3);
    for (int i = 0; i < 3; i++) {
        std::cout << a[i] << std::endl;
    }
    
    // you cannot do this. b is a runtime variable
    // normalize<int, b>(a, 3);
    
    // this is ok because c is a constant expression
    constexpr int c = 7 / 2;
    normalize<double, c>(a, 3);
    
    return 0;
}
