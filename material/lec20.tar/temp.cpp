/*
 * temp.cpp
 *
 * Example of incorrect sharing of templates (slide 6)
 */

#include "temp.h"

/* template definition here */


// advanced workaround:
// explicit template instantiation (not covered in class)
// template int min<int>(int, int);
