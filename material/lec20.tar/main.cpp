/*
 * main.cpp
 *
 * Example of incorrect sharing of templates (slide 6)
 */

#include <iostream>
#include "temp.h"

int main() 
{
    // this will not work because we are missing the 
    // template definition, which is in temp.cpp
    std::cout << min<int>(4, 9) << std::endl;  

    return 0;
}

