/*
 * tstack.cpp
 *
 * Example of template using template (slide 17/18)
 */

#include <iostream>
#include <vector>

template<class T, size_t C=8> 
class Stack { 
    std::vector<T> array;
    
public: 
    Stack() {} 
  
    bool push(const T &); 
    bool pop();           
    T * top(); 

    int empty() const { return array.size() == 0; } 
    int full() const { return array.size() >= C; } 
};

template<class T, size_t C>
bool Stack<T, C>::push(const T & item) {
    if (full()) return false;
    array.push_back(item);
    return true;
}

template<class T, size_t C>
bool Stack<T, C>::pop() {
    if(empty()) return false;
    array.pop_back();
    return true;
}

template<class T, size_t C>
T * Stack<T, C>::top() {
    if (empty()) return nullptr;
    return &array.back();
}

using namespace std;

// allows printing vectors through cout
template<typename T>
ostream& operator<<(ostream& os, const vector<T> & v)
{
    os << "[ ";
    for (auto it = v.begin(); it != v.end(); it++) {
        os << *it << ", ";
    }
    return os << "]";
}

int main() {
    Stack<vector<char>> st = Stack<vector<char>>();
    std::vector<char> * vp, v = { 'a' };
    
    cout << "Pushing elements onto stack" << endl;
    while (st.push(v)) {
        cout << v << ' '; v[0] += 2;
    }
    
    cout << endl << "stack full" << endl
         << endl << "Popping elements from stack" << endl ;
    
    while ((vp = st.top())) {
        cout << *vp << ' '; st.pop();
    }
    cout << endl << "stack empty" << endl;
    
    return 0;
}

