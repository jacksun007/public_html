/*
 * multi.cpp
 *
 * Example of multiple type parameters (slide 8)
 */

#include <iostream>

template<typename T, typename F> T convert(F v);

double foo(double d) {
    int i = convert<int>(d);	// from double to int
    char c = convert<char>(i);	// from int to char
    
    /* instantiate convert<double, char> */
    double(*func)(char) = convert; 	// function pointer
    return func(c) + 1.2;
}

int main() {
    std::cout << foo(2.5) << std::endl;
    return 0;
}

template<typename T, typename F> 
T convert(F v) {
    return (T)v;
}

