#include <atomic>
#include <thread>
#include <vector>
#include <chrono>
#include <iostream>

std::atomic<int> count(0);

void worker() {
    for (int i = 0; i < 1000000; i++)
        count++;
}

int main() {
    int nthreads = 100;
    std::vector<std::thread> threads;  
    
    auto start = std::chrono::system_clock::now();
    for (int i = 0; i < nthreads; i++) {
        std::thread th(worker);
        threads.push_back(std::move(th));
    }
    
    for (int i = 0; i < nthreads; i++)
        threads[i].join();

    auto end = std::chrono::system_clock::now();
    std::chrono::duration<double> duration = end-start;
    
    std::cout << "Test took " << duration.count() << " seconds\n";
    std::cout << "count = " << count << std::endl;
    return 0;
}
