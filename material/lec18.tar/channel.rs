/*
 * channel.rs
 *
 * Basic example of using channel (slide 25)
 *
 */
 
use std::thread; 
use std::sync::mpsc; 

fn main() { 
	let (tx, rx) = mpsc::channel(); 
	
	for i in 1..10 { 
	    let tx = mpsc::Sender::clone(&tx); 
	    thread::spawn(move || { 
	        let msg = format!("hello from {}", i);
		    tx.send(msg).unwrap(); 
	    }); 
    } 
    
    // we don't need tx in main thread 
    // uncomment otherwise program does not end
    drop(tx);

    for received in rx { 
	    println!("Got: {}", received); 
    }
}

