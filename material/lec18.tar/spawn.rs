/*
 * spawn.rs
 *
 * Basic example for starting a new thread (slide 6)
 *
 */
 
use std::thread; 
use std::time::Duration; 

fn main() {
    for i in 1..10 {
        thread::spawn(move || { 
            println!("hi number {} from thread!", i);
            thread::sleep(Duration::from_millis(1)); 
        });
    }
    
    thread::sleep(Duration::from_millis(10)); 
}
