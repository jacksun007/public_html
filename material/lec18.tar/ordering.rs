/*
 * ordering.rs
 *
 * Basic example of lock ordering (slide 35)
 *
 */
 
use std::sync::{Arc, Mutex};
use std::time::Duration;
use std::thread;
use std::io::{self, Write};

fn print_and_flush(msg: &str) {
    print!("{}", msg);
    io::stdout().flush().unwrap();
    thread::sleep(Duration::from_nanos(1));
}

fn main() {
    let locks = Arc::new((Mutex::new(0), Mutex::new(0)));
    
    let t1 = {
        let locks = locks.clone();
        thread::spawn(move || {
            let (m1, m2) = &*locks;
            for i in 0..1000 {
                let mut v1 = m1.lock().unwrap();
                let mut v2 = m2.lock().unwrap();
                *v1 += i;
                *v2 += 2*i;
                print_and_flush("t1 ");
            }
        })
    };
    
    let t2 = {
        let locks = locks.clone();
        thread::spawn(move || {
            let (m1, m2) = &*locks;
            for i in 0..1000 {
                let mut v1 = m1.lock().unwrap();
                let mut v2 = m2.lock().unwrap();
                *v1 -= i/2;
                *v2 -= i/4;
                print_and_flush("t2 ");
            }
        })
    };  
    
    t1.join().unwrap();
    t2.join().unwrap(); 
 
    let (m1, m2) = &*locks;
    let v1 = m1.lock().unwrap();
    let v2 = m2.lock().unwrap();
    println!("v1 = {}, v2 = {}", v1, v2);
}    
