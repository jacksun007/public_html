/*
 * mutex.rs
 *
 * Basic example of Mutex with Arc (slide 19)
 *
 */
 
use std::thread; 
use std::sync::Arc;
use std::sync::Mutex; 
use std::time::Instant;

fn main() {
    let counter = Arc::new(Mutex::new(0));
    let mut threads = vec!();
    let start = Instant::now();
    
    for _ in 0..100 { 
	    let counter = Arc::clone(&counter); 
	    threads.push(thread::spawn(move || {
		    for _ in 0..100000 {
		        let mut num = counter.lock().unwrap(); 
		        *num += 1;
		    } 
	    })); 
	} 
	    
    for th in threads {
        th.join().unwrap();
    }

    let duration = start.elapsed();
    let num = counter.lock().unwrap();
    println!("num = {}, took {:?}", num, duration);
}
