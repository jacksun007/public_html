/*
 * join.rs
 *
 * Example of waiting for thread to finish with join (slide 8)
 *
 */

use std::thread; 
use std::time::Duration; 

#[allow(unused_variables)]
fn main() { 
    let handle = thread::spawn(|| { 
        for i in 1..10 { 
		    println!("hi number {} from thread!", i);
            thread::sleep(Duration::from_millis(1));     
        } 
    });

    println!("hi from main!"); 
    
    handle.join().unwrap();  // wait for thread to finish
}

