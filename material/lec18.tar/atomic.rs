/*
 * atomic.rs
 *
 * Basic example of Atomic with Arc (slide 19)
 *
 */
 
use std::thread; 
use std::sync::Arc;
use std::sync::atomic::{AtomicIsize, Ordering}; 
use std::time::Instant;

fn main() {
    let count = Arc::new(AtomicIsize::new(0));
    let mut threads = vec!();
    let start = Instant::now();
    
    for _ in 0..100 { 
	    let count = Arc::clone(&count); 
	    threads.push(thread::spawn(move || {
		    for _ in 0..100000 {
		        count.fetch_add(1, Ordering::SeqCst);
		    } 
	    })); 
	} 
	    
    for th in threads {
        th.join().unwrap();
    }

    let duration = start.elapsed();
    println!("num = {:?}, took {:?}", count, duration);
}
