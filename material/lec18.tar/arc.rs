/*
 * arc.rs
 *
 * Basic example of Arc (slide 16)
 *
 */
 
use std::thread; 
use std::sync::Arc;

fn main() {
    let foo = Arc::new(vec![1, 2, 3]);
    let mut threads = vec!();

    for i in 1..10 {
        let shared = foo.clone(); // reference count +1
        threads.push(thread::spawn(move || { 
            println!("{}: {:?}, rc = {}", i, shared,
                Arc::strong_count(&shared));
                
            // compiler will complain here
            shared.push(i);
        }));
    }
    
    for th in threads {
        th.join().unwrap();
    }
    
     println!("main: rc = {}", Arc::strong_count(&foo));
}
