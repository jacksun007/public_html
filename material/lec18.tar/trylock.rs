/*
 * trylock.rs
 *
 * Basic example of trylock (slide 35)
 *
 */
 
use std::sync::{Arc, Mutex};
use std::thread;

fn main() {
    let locks = Arc::new((Mutex::new(0), Mutex::new(0)));
    
    let t1 = {
        let locks = locks.clone();
        thread::spawn(move || {
            let (m1, m2) = &*locks;
            let mut i = 0;
            while i < 1000 {
                let mut v1 =  m1.lock().unwrap();
                if let Ok(mut v2) = m2.try_lock() {
                    *v1 += i;
                    *v2 += 2*i;
                    i += 1;
                }
                else { println!("try_lock failed!"); }    
            }
        })
    };
    
    let t2 = {
        let locks = locks.clone();
        thread::spawn(move || {
            let (m1, m2) = &*locks;
            let mut i = 0;
            while i < 1000 {
                let mut v2 = m2.lock().unwrap();
                if let Ok(mut v1) = m1.try_lock() {
                    *v1 -= i/2;
                    *v2 -= i/4;
                    i += 1;
                }
            }
        })
    };  
    
    t1.join().unwrap();
    t2.join().unwrap(); 
 
    let (m1, m2) = &*locks;
    let v1 = m1.lock().unwrap();
    let v2 = m2.lock().unwrap();
    println!("v1 = {}, v2 = {}", v1, v2);
}    
