/*
 * Short example of how closure works (slide 4)
 *
 */
 
fn main() {
    let x = 5;
    let plus_x = |y| { x + y };
    let z = plus_x(8);
    println!("x + y = {}", z);
}
