
class Adam:
    pass

class Eve:
    pass

class PaternalGrandFather(Adam, Eve):
    def funcA(self):
        print('In Paternal Grandfather funcA')

class PaternalGrandMother(Adam, Eve):
    pass

class MaternalGrandFather(Adam, Eve):
    pass

class MaternalGrandMother(Adam, Eve):
    pass

class Father(PaternalGrandFather, PaternalGrandMother):
    pass

class Mother(MaternalGrandFather, MaternalGrandMother):
    def funcA(self):
        print('In Mother funcA')

class Son(Father, Mother):
    pass

print(Son.__mro__)
x = Son()
x.funcA()