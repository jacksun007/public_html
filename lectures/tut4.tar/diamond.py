class Animal:
    def whoAmI(self):
        print("I am an animal!")

class Bird(Animal):
    def fly(self):
        print("Bird is flying")
    def whoAmI(self):
        print("I am a bird!")

class Fish(Animal):
    def swim(self):
        print("Fish is swimming")
    #def whoAmI(self):
    #   print("I am a fish!")

class FlyingFish(Fish, Bird):
    pass

ff = FlyingFish()
ff.swim()
ff.fly()
ff.whoAmI()