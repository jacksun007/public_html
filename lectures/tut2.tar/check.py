#!/usr/bin/python3
#
# check.py
#
# Learning objectives:
# 
# 1. Familiarize with Python list and defaultdict
# 2. reading a text file
# 3. str.split and str.strip
# 4. Python convention: main() function and sys.argv
#
# Tutorial Problem:
#
# You are in charge of security at a private school. In this school, everyone 
# has a keycard that can access one or more rooms in the school. The access
# list is in the following format:
#
# room1 : name1, name2, ...etc
# room2 : name1, name2, ...etc
#
# You want to make sure the following policies are enforced:
#
# 1. students can only belong to one room 
# 2. at least one teacher is in every room
#
# You have the names of all the teachers. 
#
# Write a Python program to check the following policies. You may assume that
# the format of the file is correct.
#

from collections import defaultdict
import sys

TEACHERS = ["jones",   "sanders", "barnes", "edwards", 
            "simmons", "wright",  "brooks", "patterson", ]

def main():
    # intentional crash if file not found
    if len(sys.argv) == 2:
        file = open(sys.argv[1])
    else:
        file = open("school.txt")
    
    appear = defaultdict(int)
    for line in file:
        # return value unpacking
        room, ids = line.split(":")
        has_teacher = False
        for id in ids.split(","):
            id = id.strip()
            if id in TEACHERS:
                has_teacher = True
            else:
                appear[id] += 1
        if not has_teacher:
            # old style format string
            print("Warning: %s has no teachers"%(room.strip()))
    file.close()
    
    for student in appear:
        if appear[student] > 1:
            print("Warning: {} appeared more than once.".format(student))

    # new style format string
    print("{} students registered.".format(len(appear)))

# the Pythonic way to start the main function            
if __name__ == "__main__":
    main()
