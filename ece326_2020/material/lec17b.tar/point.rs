/*
 * point.rs 
 *
 * Shows how PartialOrd works (slide 5)
 * 
 */

#[derive(PartialEq, Eq, PartialOrd, Debug)]
struct Point { x: i32, y: i32, }

// Returns &T so Copy trait not needed
fn largest<T: PartialOrd>(list: &[T]) -> &T 
{ 
	let mut largest = &list[0]; 
	for item in list { 
		if *item > *largest { largest = item; } 
	} 
	largest 
}

fn main() {
    let p1 = Point{ x: 1, y: 5 };
    let p2 = Point{ x: 3, y: 0 };
    let p3 = Point{ x: 1, y: 9 };
    let mut v = vec![ p1, p2, p3 ];

    println!("before sort: {:?}", v);
    v.sort();
    
    println!("after sort: {:?}", v);
    println!("largest: {:?}", largest(&v));
}
