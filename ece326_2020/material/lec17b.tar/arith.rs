/*
 * arith.rs 
 *
 * Show how traits for arithmetic operators work (slide 7)
 * 
 */

use std::ops::Mul;
use std::env;

struct Rectangle<T> { width: T, height: T }

impl<T: Mul<Output=T> + Copy> Rectangle<T> {
    fn area(&self) -> T {
        self.width * self.height
    }
}

fn main() 
{
    let args : Vec<String> = env::args().collect();
    let tri = Rectangle {  width: args[1].parse::<f32>().unwrap(),
                          height: args[2].parse::<f32>().unwrap(),
    };
    
    println!("area = {}", tri.area());
}
