/*
 * default.rs 
 *
 * Show how Default trait works (slide 8)
 * 
 */

use std::ops::AddAssign;

fn total<T: Default + AddAssign + Copy>(list: &[T]) -> T {
    let mut sum = Default::default();
    
    for &item in list {
        sum += item;
    }

    sum
}

fn main() 
{
    let v = vec![3, 2, 5];
    let empty: Vec<f32> = Vec::new();
    let s: String = Default::default();
    
    println!("v total = {}", total(&v));
    println!("empty total = {}", total(&empty));
    println!("empty string = '{}'", s);
}
