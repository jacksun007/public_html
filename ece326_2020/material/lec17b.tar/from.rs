/*
 * from.rs 
 *
 * Show how Default trait works (slide 9)
 * 
 */

#[derive(Debug)]
enum Answer { Yes, No, Maybe }

impl From<& str> for Answer {
    fn from(s: & str) -> Self {
        match s.to_lowercase().as_str() {
            "yes" => Answer::Yes,
            "no"  => Answer::No,
            _ => Answer::Maybe,
        }
    }
}

fn main() {
    let ans = Answer::from("yes");
    println!("{:?}", ans);
    let ans: Answer = "NO".into();
    println!("{:?}", ans);
}

