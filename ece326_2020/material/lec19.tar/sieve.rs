/*
 * sieve.rs
 *
 * Shows Sieve of Eratosthenes for integer up to 50 (slide 14)
 * 
 */

fn main() {
    let starter: Vec<i32> = vec![2, 3, 5, 7];
    let largest = 50;
    
    let composites = starter.iter().map(|&x| -> Vec<i32> { 
            ((x+1)..largest).filter(|&y| y % x == 0).collect() 
        }).collect::<Vec<Vec<i32>>>(); 
    
    println!("list of multiples: ");
    for list in &composites {
        println!("{:?}", list);
    }

    let composites: Vec<i32> = composites.into_iter().flatten().collect();
        
    println!("\nflattened: {:?}\n", composites);    
        
    let primes : Vec<i32> = (2..largest).filter(
        |&x| !composites.contains(&x)).collect();
        
    println!("prime numbers: {:?}", primes);
}
