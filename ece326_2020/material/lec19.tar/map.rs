/*
 * map.rs
 *
 * Example of using map and collect (slide 12)
 * 
 */
 
fn main() {
    let v = vec![3, 6, 8];
    let c = v.iter().map(|&x| { x + 2 }).collect::<Vec<i32>>();
    println!("{:?}", c);    // [5, 8, 10]
}
