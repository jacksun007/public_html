/*
 * complex.rs
 *
 * Example for overloading arithmetic operators (slide 6)
 * 
 */

use std::ops;
use std::fmt;

struct Imaginary { i: f64, }

struct Complex { r: f64, i: f64, }

impl ops::Add<f64> for Imaginary { 
	type Output = Complex;

	fn add(self, rhs: f64) -> Self::Output { 
		Complex { i: self.i, r: rhs }
	} 
}

fn main() {
    let i = Imaginary { i: 5. };
    
    println!("ans = {}", i + 3.);
}

// TODO: does not support negative imaginary part correctly
impl fmt::Display for Complex {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{} + {}i", self.r, self.i)
    }
}
