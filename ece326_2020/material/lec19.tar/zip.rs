/*
 * zip.rs
 *
 * Simple example of how zip works (slide 13)
 * 
 */

fn main() {
	let x = vec![2, 3, 5, 7]; 
	let mut y = vec![7, 5, 1, -3];
	
	for (a, b) in x.iter().zip(y.iter_mut()) {
	    *b += a;
	}
	
	println!("y = {:?}", y);
}
