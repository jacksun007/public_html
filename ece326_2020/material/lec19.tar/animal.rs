/*
 * animal.rs
 *
 * Basic example of trait object (slide 2)
 *
 */

use std::env;

trait Animal {
    fn noise(&self) -> &'static str; 
} 

struct Sheep {} struct Cow {}

impl Animal for Sheep {
    fn noise(&self) -> &'static str {
        return "baa";
    }
}

impl Animal for Cow {
    fn noise(&self) -> &'static str {
        return "moo";
    }
}

fn random_animal(random_number: f64) -> Box<dyn Animal> { 
	if random_number < 0.5 { 
		Box::new(Sheep {}) 
	} else { 
		Box::new(Cow {}) 
	} 
}

fn main() {
    let s = env::args().skip(1).next().unwrap();
    let animal = random_animal(s.parse().unwrap()); 
    println!("It says {}", animal.noise()); 
}


