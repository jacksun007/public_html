/*
 * intoiter.rs
 *
 * Dissecting the for loop with into_iter (slide 11)
 * 
 */

fn main() {
	let v = vec![2, 3, 5, 7]; 
	
	// into_iter takes ownership of v
    let mut iter = v.into_iter();
    
    loop { 
	    match iter.next() { 
		    Some(x) => { 
		        /* body of for loop */ 
		        println!("{}", x);    
		    }, 
		    None => break, 
	    } 
    }
    
    // at this point, v has been freed
    // uncomment this for error
    // println!("{:?}", v);
}
