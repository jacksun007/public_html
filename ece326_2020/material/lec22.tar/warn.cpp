/*
 * warn.cpp
 *
 * Showing how stringification work (slide 13)
 *
 */

#include <cstdio>

#define WARN_IF(EXP) do { \
    if (EXP) { \
        fprintf (stderr, "Warning: " #EXP "\n"); \
    } \
} while (0) 

int main()
{
    int x = 2;
    WARN_IF(x == 0); 
    
    x = 0;
    WARN_IF(x == 0);
}    

