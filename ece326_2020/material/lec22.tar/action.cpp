/*
 * action.cpp
 *
 * Shows how to combine X macro and #include (slide 20)
 *
 */

#include <iostream>

#define X(e, ...) e, 
enum Action {  
#include "action.xmc"
}; 
#undef X 

float action_value(Action e) {
#define X(name, value, ...) if (e == name) { \
    return value ; } else
#include "action.xmc" 
#undef X 
    {} // the last else uses this 
    
    // should technically never reach here
    return -1.0; 
} 

int main() {
    std::cout << "STAND = " << action_value(STAND)
              << ", HIT = " << action_value(HIT) 
              << std::endl;
    return 0;
} 

