/*
 * const.cpp
 *
 * Showing how macro constants work (slide 4)
 *
 */

#define BUFFER_SIZE 1024

int main() {
    char * array = new int[BUFFER_SIZE];
    delete [] array;
    return 0;
}

int foo = X;
#define X 4
int bar = X;
int Xin = X; // the X in Xin would not be replaced
             // because macro expansion only happens
             // at the token level, and not per character

