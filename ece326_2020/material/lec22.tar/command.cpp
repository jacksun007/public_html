/*
 * command.cpp
 *
 * Showing how stringification work (slide 15)
 *
 */

#include <iostream>
#include <cstdlib>

void quit_command() { 
    std::cout << "Quitting" << std::endl;
    exit(0);
}

void help_command() {
    std::cout << "Help me" << std::endl;
}

#define COMMAND(NAME) { #NAME, NAME ## _command } 

struct Command { 
    const char *name; 
    void (*function)(); 
};

Command commands[] = { 
    COMMAND (quit), 
    COMMAND (help),
};  

#define NUM_COMMANDS (sizeof(commands)/sizeof(Command))

int main() {
    while(1) {
        std::string cmd;
        std::cout << "Enter Command: ";
        std::getline(std::cin, cmd);
        for (int i = 0; i < NUM_COMMANDS; i++) {
            if (cmd == commands[i].name) {
                commands[i].function();
                break;
            }
        }
    }
    return 0;
}

