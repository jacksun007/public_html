/*
 * xmacro.cpp
 *
 * Shows how to use X macro (slide 19)
 *
 */

#include <iostream>

#define ACTIONS \
    X(STAND) \
    X(HIT) \
    X(SURRENDER) \
    X(DOUBLE) \
    X(SPLIT) 

#define X(e) e, 
enum Action {  
    ACTIONS 
}; 
#undef X 

#define X(e) #e, 
const char * action_str[] = { 
    ACTIONS 
}; 
#undef X 

int main() {
    std::cout << action_str[HIT] << " " 
              << action_str[STAND] << std::endl;
    return 0;
} 

