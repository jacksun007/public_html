#include <iostream>

#define min_macro(X, Y) ((X) < (Y) ? (X) : (Y))

template<typename T>
T min_function(T x, T y) {
    return x < y ? x : y;
}

using namespace std;

int main()
{
    int a = 5;
    int r = min_macro(a++, 6);
    cout << "min_macro: r = " << r << ", a = " << a << endl;
    
    a = 5;
    r = min_function(a++, 6);
    cout << "min_function: r = " << r << ", a = " << a << endl;
    
    return 0;
}
